# Command/Response logs
def logRegisterChange(registerName, previousValue, currentValue, bitCount):

    # Ignore bad quality or missing values
    if previousValue is None or currentValue is None:
        return

    oldValue = int(previousValue.value)
    newValue = int(currentValue.value)

    # Detect changed bits
    changedBits = oldValue ^ newValue

    for bit in range(bitCount):

        mask = 1 << bit

        if changedBits & mask:

            oldBit = 1 if oldValue & mask else 0
            newBit = 1 if newValue & mask else 0

            # Get signal ID
            result = system.db.runNamedQuery("CommLog/GetSignalId", {"register_name": registerName, "bit_number": bit})

            if len(result) == 0:
                continue

            signalId = result[0]["id"]

            # Write change to communication log
            system.db.runNamedQuery("CommLog/InsertLog", {"signal_id": signalId, "old_value": oldBit, "new_value": newBit})
            
# Alarm logging
def logAlarmChange(previousValue, currentValue):

    # Ignore bad quality or missing values
    if previousValue is None or currentValue is None:
        return

    if not previousValue.quality.isGood() or not currentValue.quality.isGood():
        return

    oldCode = int(previousValue.value)
    newCode = int(currentValue.value)

    # Ignore if value did not change
    if oldCode == newCode:
        return

    # New alarm: 0 -> error code
    if oldCode == 0 and newCode != 0:
        system.db.runNamedQuery("Alarm/InsertAlarmLog", {"code": newCode})

    # Clear alarm: error code -> 0
    elif oldCode != 0 and newCode == 0:
        system.db.runNamedQuery("Alarm/FinishAlarmLog", {"code": oldCode})
        
        