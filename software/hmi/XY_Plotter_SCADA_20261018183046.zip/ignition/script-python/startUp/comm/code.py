def setupSignals():

	signals = [

	    # STW - PLC -> ESP32 UINT, 16 bit
	    {
	        "register_name": "STW",
	        "data_type": "UINT",
	        "bit_number": 0,
	        "signal_name": "stw_bit_stop",
	        "description": "Stop not active",
	        "direction": "PLC -> ESP32",
	        "operation_type": "WRITE"
	    },
	    {
	        "register_name": "STW",
	        "data_type": "UINT",
	        "bit_number": 1,
	        "signal_name": "stw_bit_estop",
	        "description": "Estop not active",
	        "direction": "PLC -> ESP32",
	        "operation_type": "WRITE"
	    },
	    {
	        "register_name": "STW",
	        "data_type": "UINT",
	        "bit_number": 2,
	        "signal_name": "stw_bit_auto",
	        "description": "Auto mode",
	        "direction": "PLC -> ESP32",
	        "operation_type": "WRITE"
	    },
	    {
	        "register_name": "STW",
	        "data_type": "UINT",
	        "bit_number": 3,
	        "signal_name": "stw_bit_move",
	        "description": "Move permission",
	        "direction": "PLC -> ESP32",
	        "operation_type": "WRITE"
	    },
	    {
	        "register_name": "STW",
	        "data_type": "UINT",
	        "bit_number": 4,
	        "signal_name": "stw_bit_home",
	        "description": "Go home",
	        "direction": "PLC -> ESP32",
	        "operation_type": "WRITE"
	    },
	    {
	        "register_name": "STW",
	        "data_type": "UINT",
	        "bit_number": 5,
	        "signal_name": "stw_bit_clean",
	        "description": "Clean buffer",
	        "direction": "PLC -> ESP32",
	        "operation_type": "WRITE"
	    },
	    {
	        "register_name": "STW",
	        "data_type": "UINT",
	        "bit_number": 6,
	        "signal_name": "stw_bit_man_pen_dn",
	        "description": "Manual pen down",
	        "direction": "PLC -> ESP32",
	        "operation_type": "WRITE"
	    },
	    {
	        "register_name": "STW",
	        "data_type": "UINT",
	        "bit_number": 7,
	        "signal_name": "stw_bit_man_move_x_pos",
	        "description": "Manual go X+",
	        "direction": "PLC -> ESP32",
	        "operation_type": "WRITE"
	    },
	    {
	        "register_name": "STW",
	        "data_type": "UINT",
	        "bit_number": 8,
	        "signal_name": "stw_bit_man_move_x_neg",
	        "description": "Manual go X-",
	        "direction": "PLC -> ESP32",
	        "operation_type": "WRITE"
	    },
	    {
	        "register_name": "STW",
	        "data_type": "UINT",
	        "bit_number": 9,
	        "signal_name": "stw_bit_man_move_y_pos",
	        "description": "Manual go Y+",
	        "direction": "PLC -> ESP32",
	        "operation_type": "WRITE"
	    },
	    {
	        "register_name": "STW",
	        "data_type": "UINT",
	        "bit_number": 10,
	        "signal_name": "stw_bit_man_move_y_neg",
	        "description": "Manual go Y-",
	        "direction": "PLC -> ESP32",
	        "operation_type": "WRITE"
	    },
	
	    # ZSW1 - ESP32 -> PLC BYTE, 8 bit
	    {
	        "register_name": "ZSW1",
	        "data_type": "BYTE",
	        "bit_number": 0,
	        "signal_name": "zsw1_readyForNextPnt",
	        "description": "Ready for next point",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW1",
	        "data_type": "BYTE",
	        "bit_number": 1,
	        "signal_name": "zsw1_rdyForEnabled",
	        "description": "Ready to enable",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW1",
	        "data_type": "BYTE",
	        "bit_number": 2,
	        "signal_name": "zsw1_enabled",
	        "description": "Drivers enabled",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW1",
	        "data_type": "BYTE",
	        "bit_number": 3,
	        "signal_name": "zsw1_off1",
	        "description": "Stop active",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW1",
	        "data_type": "BYTE",
	        "bit_number": 4,
	        "signal_name": "zsw1_off2",
	        "description": "Estop active",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW1",
	        "data_type": "BYTE",
	        "bit_number": 5,
	        "signal_name": "zsw1_penDn",
	        "description": "Pen down",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW1",
	        "data_type": "BYTE",
	        "bit_number": 6,
	        "signal_name": "zsw1_rdyContinueDrw",
	        "description": "Ready to continue",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW1",
	        "data_type": "BYTE",
	        "bit_number": 7,
	        "signal_name": "zsw1_readyStartNewDrw",
	        "description": "Ready for drawing",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	
	    ## ZSW2 - ESP32 -> PLC # BYTE, 8 bit
	    {
	        "register_name": "ZSW2",
	        "data_type": "BYTE",
	        "bit_number": 0,
	        "signal_name": "zsw2_actDrwingProcc",
	        "description": "Drawing active",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW2",
	        "data_type": "BYTE",
	        "bit_number": 1,
	        "signal_name": "zsw2_snsr_home_x",
	        "description": "X home reached",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW2",
	        "data_type": "BYTE",
	        "bit_number": 2,
	        "signal_name": "zsw2_snsr_home_y",
	        "description": "Y home reached",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW2",
	        "data_type": "BYTE",
	        "bit_number": 3,
	        "signal_name": "zsw2_snsr_limit_x",
	        "description": "X limit reached",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW2",
	        "data_type": "BYTE",
	        "bit_number": 4,
	        "signal_name": "zsw2_snsr_limit_y",
	        "description": "Y limit reached",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW2",
	        "data_type": "BYTE",
	        "bit_number": 5,
	        "signal_name": "zsw2_moving_auto",
	        "description": "Moving in Auto",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW2",
	        "data_type": "BYTE",
	        "bit_number": 6,
	        "signal_name": "zsw2_moving_manual",
	        "description": "Moving in Manual",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    },
	    {
	        "register_name": "ZSW2",
	        "data_type": "BYTE",
	        "bit_number": 7,
	        "signal_name": "zsw2_moving_home",
	        "description": "Moving to Home",
	        "direction": "ESP32 -> PLC",
	        "operation_type": "READ"
	    }
	]
	
	# Insert or update signal definitions
	for signal in signals:
	    system.db.runNamedQuery("System/InsertSignal", signal)
	    