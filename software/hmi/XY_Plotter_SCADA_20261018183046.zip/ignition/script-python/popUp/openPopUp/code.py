# Opens default popup window
# Used for success, error, warning and info messages
# Ex. shared.Sidebar -> Custom props -> Change scripts
def openDefaultPopUp(title = "Message", messageLine1 = "", messageLine2 = "", messageLine3 = "", type = "info"):
	
    system.perspective.openPopup(
        id = "PopUpDefault",
        view = "Shared/PopUp/PopUpDefault",
        params = {
            "title": title,
            "type": type,
            "messageLine1": messageLine1,
            "messageLine2": messageLine2,
            "messageLine3": messageLine3
        },
        title = title,
        modal = True,
        draggable = False,
        resizable = False,
        showCloseIcon = True
    )
    
def openDeletePopUp(title = "Message", messageLine1 = "", messageLine2 = "", messageLine3 = "", type = "info", drawingId = None):
	
    system.perspective.openPopup(
        id = "PopUpDelete",
        view = "Shared/PopUp/PopUpDelete",
        params = {
            "title": title,
            "type": type,
            "messageLine1": messageLine1,
            "messageLine2": messageLine2,
            "messageLine3": messageLine3,
            "drawingId": drawingId
        },
        title = title,
        modal = True,
        draggable = False,
        resizable = False,
        showCloseIcon = True
    )