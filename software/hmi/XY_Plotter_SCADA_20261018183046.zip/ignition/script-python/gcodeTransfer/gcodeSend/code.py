def writeOpcChecked(paths, values):

    results = system.opc.writeValues("CodesysOpcUa", paths, values)

    for i, quality in enumerate(results):
        if not quality.isGood():
            raise Exception("OPC write failed: {} - {}".format(paths[i], quality))

def gcodeSend(drawing_id):
	
	logger = system.util.getLogger("GcodeTransfer")
	
	# OPC Item Path
	basePoint = "nsu=CODESYSSPV3/3S/IecVarAccess;s=|var|CODESYS Control for Raspberry Pi 64 SL.Application.Drawing.Points"
	baseContour = "nsu=CODESYSSPV3/3S/IecVarAccess;s=|var|CODESYS Control for Raspberry Pi 64 SL.Application.Drawing.Contour"
	
	# Query execution
	result = system.db.runNamedQuery("Drawing/GetGcode", {"drawing_id": drawing_id})	
	gcode = result[0]["gcode_text"]
	
	# Find the first G1 command
	firstG1 = gcode.find("G1")
	
	# Find the last M5 before the first G1
	firstM5 = gcode.rfind("M5", 0, firstG1)
	
	# Remove initialization commands before this M5
	gcode = gcode[firstM5:]
	
	# Split to lines
	lines = gcode.splitlines()
	
	# Initialization
	points = []
	contours = []	
	currentStartIndex = None
	currentPointCount = 0	
	CmdType = 0
	Speed = 0
	
	# Gcode parsing
	for line in lines:
		
		if line.startswith("M5"):
			
			# Close previous contour
			if currentStartIndex is not None and currentPointCount > 0:
				contours.append({"StartIndex": currentStartIndex, "PointCount": currentPointCount})
			
			# Start new contour
			currentStartIndex = len(points) + 1
			currentPointCount = 0
			
			CmdType = 2
			
		elif line.startswith("M3"):
			CmdType = 1
			
		elif line.startswith("G1"):
			
			# Get ["G1", "F2000.0", "X144.716953", "Y149.715306"]
			parts = line.replace(";", "").split()
			
			# Get all data for point in engineering units
			for part in parts:
				
				if part.startswith("F"):
					Speed = int(float(part[1:]))
		
				elif part.startswith("X"):
					Coord_X = int(round(float(part[1:]) * 100))
		
				elif part.startswith("Y"):
					Coord_Y = int(round(float(part[1:]) * 100))
			
			currentPointCount += 1	
			points.append({"CmdType": CmdType, "Speed": Speed, "Coord_X": Coord_X, "Coord_Y": Coord_Y})
		
	# Close the last contour
	if currentStartIndex is not None and currentPointCount > 0:
	    contours.append({"StartIndex": currentStartIndex, "PointCount": currentPointCount})
	    	
	# Update drawing totals
	system.tag.writeBlocking(["[default]Drawing/TotalNumbContours", "[default]Drawing/TotalNumbPoints"], [len(contours), len(points)])

	# Write points to OPC
	batchSize = 200
	
	# Point[0] is reserved and must always remain empty
	paths = [
	    "%s[0].CmdType" % basePoint,
	    "%s[0].Speed" % basePoint,
	    "%s[0].Coord_X" % basePoint,
	    "%s[0].Coord_Y" % basePoint
	]
	
	values = [0, 0, 0, 0]
	
	writeOpcChecked(paths, values)

	for start in range(0, len(points), batchSize):

		# Limit the last batch to the actual number of points
	    end = min(start + batchSize, len(points))
	    paths = []
	    values = []

		# Build OPC paths and values for the current batch
	    for i in range(start, end):
	
	        point = points[i]
	
	        paths.extend([
	            "%s[%d].CmdType" % (basePoint, i + 1),
	            "%s[%d].Speed" % (basePoint, i + 1),
	            "%s[%d].Coord_X" % (basePoint, i + 1),
	            "%s[%d].Coord_Y" % (basePoint, i + 1)
	        ])
	
	        values.extend([
	            point["CmdType"],
	            point["Speed"],
	            point["Coord_X"],
	            point["Coord_Y"]
	        ])
	
	    writeOpcChecked(paths, values)
	
	# Write contours to OPC
	batchSize = 100
	
	# Contour[0] is reserved and must always remain empty
	paths = [
	    "%s[0].StartIndex" % baseContour,
	    "%s[0].PointCount" % baseContour,
	]
	
	# Write the Contour[0] to PLC
	values = [0, 0]
	writeOpcChecked(paths, values)
	
	# Write contours to PLC in batches
	for start in range(0, len(contours), batchSize):
		
		# Limit the last batch to the actual number of contours
	    end = min(start + batchSize, len(contours))
	    paths = []
	    values = []
		
		# Build OPC paths and values for the current batch
	    for i in range(start, end):
	
	        contour = contours[i]
	
	        paths.extend([
	            "%s[%d].StartIndex" % (baseContour, i + 1),
	            "%s[%d].PointCount" % (baseContour, i + 1)
	        ])
	
	        values.extend([
	            contour["StartIndex"],
	            contour["PointCount"]
	        ])
		
		# Write the current batch to PLC
	    writeOpcChecked(paths, values)
	
	# Clear unused points
	for start in range(len(points) + 1, 7001, batchSize):

		# Limit the last batch to the actual number of points
	    end = min(start + batchSize, 7001)
	    paths = []
	    values = []

		# Build OPC paths and values for the current batch
	    for i in range(start, end):
	
	        paths.extend([
	            "%s[%d].CmdType" % (basePoint, i),
	            "%s[%d].Speed" % (basePoint, i),
	            "%s[%d].Coord_X" % (basePoint, i),
	            "%s[%d].Coord_Y" % (basePoint, i)
	        ])
	
	        values.extend([0, 0, 0, 0])

		# Write the current batch to PLC
	    writeOpcChecked(paths, values)

	# Clear unused contours
	for start in range(len(contours) + 1, 701, batchSize):

		# Limit the last batch to the actual number of contours
	    end = min(start + batchSize, 701)
	    paths = []
	    values = []

		# Build OPC paths and values for the current batch
	    for i in range(start, end):
	
	        paths.extend([
	            "%s[%d].StartIndex" % (baseContour, i),
	            "%s[%d].PointCount" % (baseContour, i)
	        ])
	
	        values.extend([0, 0])
	        
		# Write the current batch to PLC	
	    writeOpcChecked(paths, values)
	
	logger.info("G-code loaded: {} points, {} contours".format(len(points), len(contours)))
	return True
