# Clear ESP32 buffer
def clearBuffer(timeoutMs=3000):

    import time

    logger = system.util.getLogger("PlotterBuffer")

    STOP = "[default]DB/StopCmd"
    CLEAN = "[default]DB/CleanCmd"
    POINTS = "[default]ESP32_Response/ResponsePointsInBuffer"
    EXPECTED = "[default]ESP32_Response/ResponseNumExpected"

    try:
        # Stop motion and reset CLEAN for a new rising edge
        results = system.tag.writeBlocking([STOP, CLEAN], [True, False])

        if not all(q.isGood() for q in results):
            raise Exception("Failed to write STOP/CLEAN")

        time.sleep(0.2)

        # Activate buffer cleaning
        result = system.tag.writeBlocking([CLEAN], [True])

        if not result[0].isGood():
            raise Exception("Failed to activate CLEAN")

        # Wait for ESP32 confirmation
        start = time.time()

        while (time.time() - start) * 1000 < timeoutMs:

            values = system.tag.readBlocking([POINTS, EXPECTED])

            if all(v.quality.isGood() for v in values):

                points = values[0].value
                expected = values[1].value

                if points == 0 and expected == 1:
                    logger.info("ESP32 buffer cleared")
                    return True

            time.sleep(0.1)

        logger.error("Buffer cleaning timeout")
        return False

    except Exception as e:
    	
        logger.error("Buffer cleaning failed: {}".format(str(e)))
        return False

    finally:
    	
        # Always release CLEAN, but leave STOP active
        system.tag.writeBlocking([CLEAN], [False])
        