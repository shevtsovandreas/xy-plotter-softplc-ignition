from java.util import Base64
import re

# Builder for uploader on event
def buildPreviewSvg(contours, bounds, width, height):
	
	# Empty drawing detection
	if not contours:
		raise Exception("The drawing file is empty")
	
	# Drawing coordinate limits from G-code
	# minX/minY - lowest coordinates used by the drawing
	# maxX/maxY - highest coordinates used by the drawing
	minX = float(bounds["minX"])
	maxX = float(bounds["maxX"])
	minY = float(bounds["minY"])
	maxY = float(bounds["maxY"])
	
	# Drawing size
	drawingWidth = float(width)
	drawingHeight = float(height)
	
	# Check that the drawing size is valid
	if drawingWidth <= 0 or drawingHeight <= 0:
		raise Exception("Drawing width and height must be greater than 0")
	
	# Add empty space around the drawing
	# 5% of drawing size, but at least 2 units on each side
	paddingX = max(drawingWidth * 0.05, 2.0)
	paddingY = max(drawingHeight * 0.05, 2.0)
	
	# SVG viewBox start position
	# X starts before minX by paddingX
	# Y is inverted because SVG Y-axis points down
	viewMinX = minX - paddingX
	viewMinY = -(maxY + paddingY)
	
	# SVG viewBox total size including padding on both sides
	viewWidth = drawingWidth + paddingX * 2.0
	viewHeight = drawingHeight + paddingY * 2.0

	pathParts = []
	
	# My G-code: contour = [{"x": 50.346458, "y": 124.790019}, {"x": 50.016258, "y": 127.711045} ...}]
	for contour in contours:
		
		# Basic protection
		if len(contour) < 2:
			raise Exception("Contour must contain at least 2 points")
		
		# First point is G1 F2000.0 X50.346458 Y124.790019;
		firstPoint = contour[0]
		
		# SVG command Move To: M 50.346458 124.790019 
		pathParts.append("M %.3f %.3f"	% (float(firstPoint["x"]), float(firstPoint["y"])))
		
		# Next point G1 F1000.0 X50.016258 Y127.711045;
		for point in contour[1:]:
			
			# SVG command Line To: M 50.016258 127.711045 
			pathParts.append("L %.3f %.3f"	% (float(point["x"]), float(point["y"])	))
	
	# Ex.: M 50.346 124.790 L 50.016 127.711 L 49.681 128.092 L 49.105 128.270 M 81.027 131.143 L 79.380 131.766 ...
	path = " ".join(pathParts)

	svg = """
	<svg
		xmlns="http://www.w3.org/2000/svg"
		viewBox="%(viewMinX).3f %(viewMinY).3f %(viewWidth).3f %(viewHeight).3f"
		preserveAspectRatio="xMidYMid meet"
	>
		<rect
			x="%(viewMinX).3f"
			y="%(viewMinY).3f"
			width="%(viewWidth).3f"
			height="%(viewHeight).3f"
			fill="transparent"
		/>

		<g transform="scale(1,-1)">

			<path
				d="%(path)s"
				fill="none"
				stroke="#2563EB"
				stroke-width="0.5"
				stroke-linecap="round"
				stroke-linejoin="round"
				vector-effect="non-scaling-stroke"
			/>

		</g>
	</svg>
	""" % {
		"viewMinX": viewMinX,
		"viewMinY": viewMinY,
		"viewWidth": viewWidth,
		"viewHeight": viewHeight,
		"path": path
	}
	
	# Convert the SVG text to UTF-8 bytes and encode it as a Base64 string
	encoded = Base64.getEncoder().encodeToString(svg.encode("UTF-8"))
	
	# Create a data URL that can be used directly as an image source in Perspective
	return "data:image/svg+xml;base64," + encoded

def refresh(view):
	contours = view.custom.gcodeContours

	if not contours:
		return

	view.getChild("root").getChild("ImageGenerator").getChild("GcodeImage").props.source = buildSvg(
		contours=contours,
		bounds=view.custom.gcodeBounds,
		currentContour=view.custom.currentContour,
		currentPoint=view.custom.currentPoint,
		currentX=view.custom.currentX,
		currentY=view.custom.currentY
	)