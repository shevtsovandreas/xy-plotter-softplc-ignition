from java.util import Base64
import re

# Parser for uploader on event
def parseGcode(text):
	
	# Create variables
	currentX = 0.0
	currentY = 0.0
	pointCount = 0
	penDown = False
	currentContour = None
	contours = []
	allX = []
	allY = []

	# G-code into lines
	for rawLine in text.splitlines():
		
		# One line before moving to the next line -Enter-
		# Ex. G1 F2000.0 X50.346458 Y124.790019;
		line = rawLine.upper().strip() 								
		
		# Empty line found
		if not line:
			continue
		
		# Checking if the line contains command (G1 or M3 or any letter + number)
		# List [("G","1"), ("F","2000.0"), ("X","50.346458"), ("Y","124.790019")]
		commands = re.findall(r"([A-Z])([-+]?\d+(?:\.\d+)?)", line)
		
		# No commands line found
		if not commands:
			continue

		values = {}
		
		# ("G", "1") -> values["G"] = float("1") -> values["G"] = 1.0 & ("F","2000.0") -> values["F"] = 2000.0 etc
		# Dictionary values = {("G","1.0"), ("F","2000.0"), ("X","50.346458"), ("Y","124.790019")}
		for letter, number in commands:
			try:
				values[letter] = float(number)
			except:
				pass
	
		# Command G90 / G91
		
		# Absolute positioning - supported
		if "G" in values and int(values["G"]) == 90:
			continue
        
		if "G" in values and int(values["G"]) == 91:
		    raise Exception("G91 relative positioning is not supported")

		# Command M3 / M5
		if "M" in values:

			mCode = int(values["M"])
			
			# Start a new contour
			if mCode == 3:

				penDown = True
				currentContour = [(currentX, currentY)]
				continue
			
			# Finish and save the current contour if it has at least 2 points
			elif mCode == 5:

				penDown = False
				if (currentContour is not None and len(currentContour) >= 2):
					contours.append(currentContour)
				currentContour = None
				continue
				
		# Command G21
		if "G" in values and int(values["G"]) == 21:
			continue

		# Command G1
		if "G" not in values:
			continue

		gCode = int(values["G"])
		
		# Only G1 command supported
		if gCode != 1:
			raise Exception("Unsupported G-code: G%s" % gCode)
		
		pointCount += 1                                                        # Count G1 point
		
		# Target update
		targetX = currentX
		targetY = currentY

		if "X" in values:
			targetX = values["X"]

		if "Y" in values:
			targetY = values["Y"]

		# Draw only if the pen is down
		if penDown:
			
			# Start a new contour
			if currentContour is None:
				currentContour = [(currentX, currentY)]

			currentContour.append((targetX, targetY))

			allX.append(targetX)
			allY.append(targetY)

		# Update current position regardless of pen state
		currentX = targetX
		currentY = targetY

	# File must not end with an unfinished contour (M5 is not detected)
	if currentContour is not None:
	    raise Exception("G-code ended before M5")

	# Perspective format
	perspectiveContours = []

	for contour in contours:
		
		newContour = []

		for pointX, pointY in contour:
			newContour.append({"x": float(pointX), "y": float(pointY)})

		perspectiveContours.append(newContour)

	# Identify max and min coordinates
	allX = []
	allY = []

	# Check all points in all contours
	for contour in perspectiveContours:
		for point in contour:
			allX.append(float(point["x"]))
			allY.append(float(point["y"]))
	
	# Coordinates X
	minX = min(allX)
	maxX = max(allX)
	
	# Coordinates Y
	minY = min(allY)
	maxY = max(allY)

	# Draqing dimensions
	drawingWidth = maxX - minX
	drawingHeight = maxY - minY

	return {
		"contours": perspectiveContours,

		"minX": float(minX),
		"maxX": float(maxX),
		"minY": float(minY),
		"maxY": float(maxY),

		"width": float(drawingWidth),
		"height": float(drawingHeight),

		"points": int(pointCount),
		"contourCount": int(len(perspectiveContours))
	}