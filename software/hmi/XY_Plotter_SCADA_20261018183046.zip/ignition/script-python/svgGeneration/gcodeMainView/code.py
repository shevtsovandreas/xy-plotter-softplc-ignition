from java.util import Base64
import re


# Load active drawing from database when Operator View is opened
def loadActiveDrawing(view):

	# Get active drawing from database
	result = system.db.runNamedQuery("Drawing/GetActiveDrawing", {})

	# No active drawing found
	if len(result) == 0:
		view.custom.drawingId = 0
		view.custom.drawingName = ""
		view.custom.gcodeContours = []
		view.custom.gcodeBounds = {}
		return

	# Get first row from query result
	row = result[0]

	# Drawing information from database
	drawingId = row["drawing_id"]
	drawingName = row["name"]
	gcodeText = row["gcode_text"]

	# Parse stored G-code
	parsed = svgGeneration.gcodeParse.parseGcode(gcodeText)

	# Save drawing information in View custom properties
	view.custom.drawingId = drawingId
	view.custom.drawingName = drawingName

	# Save parsed contours
	# Format: [[{"x": 10.0, "y": 20.0}, {"x": 15.0, "y": 25.0}], ...]
	view.custom.gcodeContours = parsed["contours"]

	# Save drawing coordinate limits
	view.custom.gcodeBounds = {
		"minX": parsed["minX"],
		"maxX": parsed["maxX"],
		"minY": parsed["minY"],
		"maxY": parsed["maxY"]
	}

	# Draw loaded G-code on Operator screen
	refresh(view)


# Builder for G-code image on Operator View
def buildSvg(contours, bounds, currentContour=0, currentPoint=0, currentX=None, currentY=None):

	# Empty drawing detection
	if not contours:
		raise Exception("The drawing is empty")

	# Drawing coordinate limits from G-code
	minX = float(bounds["minX"])
	maxX = float(bounds["maxX"])
	minY = float(bounds["minY"])
	maxY = float(bounds["maxY"])

	# Calculate drawing dimensions
	drawingWidth = maxX - minX
	drawingHeight = maxY - minY

	# Basic protection against zero-size drawing
	if drawingWidth <= 0:
		drawingWidth = 1.0

	if drawingHeight <= 0:
		drawingHeight = 1.0

	# Add empty space around the drawing
	paddingX = max(drawingWidth * 0.05, 2.0)
	paddingY = max(drawingHeight * 0.05, 2.0)

	# SVG viewBox position and size
	viewMinX = minX - paddingX
	viewMinY = -(maxY + paddingY)

	viewWidth = drawingWidth + paddingX * 2.0
	viewHeight = drawingHeight + paddingY * 2.0

	# SVG path commands
	# pendingParts   - drawing not executed yet
	# completedParts - drawing already executed
	pendingParts = []
	completedParts = []

	# PLC point numbering starts from 1
	# Point[0] is reserved and empty
	globalPointNumber = 1

	# Check every contour
	for contourIndex, contour in enumerate(contours):

		# Basic protection
		if len(contour) < 2:
			globalPointNumber += len(contour)
			continue

		# Real contour number starts from 1
		contourNumber = contourIndex + 1

		# First point of current contour
		firstPoint = contour[0]

		# Contour already completed
		if contourNumber <= currentContour:

			completedParts.append(
				"M %.3f %.3f" % (
					float(firstPoint["x"]),
					float(firstPoint["y"])
				)
			)

			for point in contour[1:]:

				completedParts.append(
					"L %.3f %.3f" % (
						float(point["x"]),
						float(point["y"])
					)
				)

		# Current contour
		elif contourNumber == currentContour + 1:

			# Start completed path from first contour point
			completedParts.append(
				"M %.3f %.3f" % (
					float(firstPoint["x"]),
					float(firstPoint["y"])
				)
			)

			pendingStarted = False

			# Check every point in current contour
			for pointIndex in range(1, len(contour)):

				point = contour[pointIndex]

				# Current global PLC point number
				pointNumber = globalPointNumber + pointIndex

				# Point already completed
				if pointNumber < currentPoint:

					completedParts.append(
						"L %.3f %.3f" % (
							float(point["x"]),
							float(point["y"])
						)
					)

				# Current segment
				elif pointNumber == currentPoint and currentX is not None and currentY is not None:

					# Draw completed part up to actual machine position
					completedParts.append(
						"L %.3f %.3f" % (
							float(currentX),
							float(currentY)
						)
					)

					# Draw remaining part from actual machine position
					pendingParts.append(
						"M %.3f %.3f" % (
							float(currentX),
							float(currentY)
						)
					)

					pendingParts.append(
						"L %.3f %.3f" % (
							float(point["x"]),
							float(point["y"])
						)
					)

					pendingStarted = True

				# Point still pending
				else:

					if not pendingStarted:

						previousPoint = contour[pointIndex - 1]

						pendingParts.append(
							"M %.3f %.3f" % (
								float(previousPoint["x"]),
								float(previousPoint["y"])
							)
						)

						pendingStarted = True

					pendingParts.append(
						"L %.3f %.3f" % (
							float(point["x"]),
							float(point["y"])
						)
					)

		# Contour has not started yet
		else:

			pendingParts.append(
				"M %.3f %.3f" % (
					float(firstPoint["x"]),
					float(firstPoint["y"])
				)
			)

			for point in contour[1:]:

				pendingParts.append(
					"L %.3f %.3f" % (
						float(point["x"]),
						float(point["y"])
					)
				)

		# Move global point number to next contour
		globalPointNumber += len(contour)

	# Convert command lists into SVG path strings
	pendingPath = " ".join(pendingParts)
	completedPath = " ".join(completedParts)

	# Current machine position marker
	marker = ""

	# Draw marker only when both coordinates are available
	if currentX is not None and currentY is not None:

		marker = """
			<g>
				<circle
					cx="%.3f"
					cy="%.3f"
					r="2.8"
					fill="#DC2626"
					fill-opacity="0.18"
					stroke="#DC2626"
					stroke-width="0.7"
					vector-effect="non-scaling-stroke"
				/>

				<circle
					cx="%.3f"
					cy="%.3f"
					r="0.9"
					fill="#DC2626"
					vector-effect="non-scaling-stroke"
				/>
			</g>
		""" % (
			float(currentX),
			float(currentY),
			float(currentX),
			float(currentY)
		)

	# Build SVG
	svg = """
	<svg
		xmlns="http://www.w3.org/2000/svg"
		viewBox="%(viewMinX).3f %(viewMinY).3f %(viewWidth).3f %(viewHeight).3f"
		preserveAspectRatio="xMidYMid meet"
	>

		<rect
			x="%(viewMinX).3f"
			y="%(viewMinY).3f"
			width="%(viewWidth).3f"
			height="%(viewHeight).3f"
			fill="transparent"
		/>

		<g transform="scale(1,-1)">

			<!-- Drawing not executed yet -->
			<path
				d="%(pendingPath)s"
				fill="none"
				stroke="#CBD5E1"
				stroke-width="0.45"
				stroke-linecap="round"
				stroke-linejoin="round"
				vector-effect="non-scaling-stroke"
			/>

			<!-- Drawing already executed -->
			<path
				d="%(completedPath)s"
				fill="none"
				stroke="#2563EB"
				stroke-width="0.55"
				stroke-linecap="round"
				stroke-linejoin="round"
				vector-effect="non-scaling-stroke"
			/>

			<!-- Current machine position -->
			%(marker)s

		</g>

	</svg>
	""" % {
		"viewMinX": viewMinX,
		"viewMinY": viewMinY,
		"viewWidth": viewWidth,
		"viewHeight": viewHeight,
		"pendingPath": pendingPath,
		"completedPath": completedPath,
		"marker": marker
	}

	# Convert SVG text to UTF-8 bytes and encode it as Base64
	encoded = Base64.getEncoder().encodeToString(svg.encode("UTF-8"))

	# Create data URL for Perspective Image props.source
	return "data:image/svg+xml;base64," + encoded


# Refresh G-code image on Operator screen
def refresh(view):

	# Get parsed contours stored in View
	contours = view.custom.gcodeContours

	# Nothing to draw
	if not contours:
		return

	# Rebuild SVG using current execution position
	view.getChild("root").getChild("ImageGenerator").getChild("GcodeImage").props.source = buildSvg(
		contours=contours,
		bounds=view.custom.gcodeBounds,
		currentContour=view.custom.currentContour,
		currentPoint=view.custom.currentPoint,
		currentX=view.custom.currentX,
		currentY=view.custom.currentY
	)