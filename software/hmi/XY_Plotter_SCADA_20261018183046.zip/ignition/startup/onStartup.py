def onStartup():
	
	## Create communication log database structure
	system.db.runNamedQuery("System/CreateTableCommSignal", {})
	system.db.runNamedQuery("System/CreateTableCommLog", {})
	system.db.runNamedQuery("System/CreateTimeIndex", {})
	system.db.runNamedQuery("System/CreateSignalIndex", {})
	
	# Initialize communication signal definitions
	startUp.comm.setupSignals()
	
	# Create application database structure
	system.db.runNamedQuery("System/CreateTables", {})
	
	# Initialize error catalog
	system.db.runNamedQuery("System/SetupErrorCatalog", {})