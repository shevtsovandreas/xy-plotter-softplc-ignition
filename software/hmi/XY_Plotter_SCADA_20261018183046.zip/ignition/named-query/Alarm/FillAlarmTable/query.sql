-- Get alarm history with catalog information
SELECT
    h.id,
    h.code,
    c.source,
    c.name,
    c.description,
    c.priority,
    h.start_timestamp,
    h.finish_timestamp,
    h.state

FROM error_history h

-- Get alarm information
JOIN error_catalog c ON c.code = h.code

-- Apply active and cleared filters
WHERE (:active = TRUE AND h.state = 'ACTIVE') OR (:cleared = TRUE AND h.state = 'CLEARED')

-- Show newest alarms first
ORDER BY h.start_timestamp DESC

-- Limit displayed history
LIMIT 100;