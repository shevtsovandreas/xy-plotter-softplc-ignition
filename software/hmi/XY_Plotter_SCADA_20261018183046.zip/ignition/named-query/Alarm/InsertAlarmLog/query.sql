INSERT INTO error_history (
    code,
    start_timestamp,
    finish_timestamp,
    state
)
VALUES (
    :code,
    CURRENT_TIMESTAMP,
    NULL,
    'ACTIVE'
)
ON CONFLICT DO NOTHING;