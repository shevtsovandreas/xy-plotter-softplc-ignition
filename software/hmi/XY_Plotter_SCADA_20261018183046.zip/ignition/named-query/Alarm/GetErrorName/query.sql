SELECT name
FROM error_catalog
WHERE code = :code
LIMIT 1