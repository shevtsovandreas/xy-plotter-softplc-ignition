UPDATE error_history
SET
    finish_timestamp = CURRENT_TIMESTAMP,
    state = 'CLEARED'
WHERE code = :code
  AND finish_timestamp IS NULL
  AND state = 'ACTIVE';