-- Called from Pages/3_IO/Table -> Query Binding
-- Get communication log data with signal details
SELECT
    TO_CHAR(cl.event_time, 'HH24:MI:SS.MS') AS time,
    cs.direction AS direction,

    -- Determine operation type by register
    CASE
        WHEN cs.register_name = 'STW' THEN 'WRITE'
        ELSE 'READ'
    END AS type,

    CONCAT(cs.register_name, '.', cs.bit_number) AS register_bit,

    -- Show bit state transition
    CONCAT(cl.old_value, ' → ', cl.new_value) AS value,

    cs.signal_name AS signal_name,
    cs.description AS description

FROM comm_log cl

-- Get signal information
JOIN comm_signal cs ON cs.id = cl.signal_id

-- Apply command and response filters
WHERE (:commands = TRUE AND cs.register_name = 'STW') OR (:responses = TRUE AND cs.register_name IN ('ZSW1', 'ZSW2'))

-- Show newest events first
ORDER BY cl.event_time DESC

-- Limit displayed history
LIMIT 100;