-- Called from GW scripts diagnosticLogs.addLog.logRegisterChange
-- Insert a bit change into the communication log
INSERT INTO comm_log
(
    signal_id,
    old_value,
    new_value
)
VALUES
(
    :signal_id,
    :old_value,
    :new_value
);