-- Called from GW scripts diagnosticLogs.addLog.logRegisterChange
-- Get signal ID by register and bit number
SELECT id
FROM comm_signal
WHERE register_name = :register_name AND bit_number = :bit_number;