INSERT INTO error_catalog (
    code,
    source,
    name,
    description,
    priority
)
VALUES
    (1000, 'ESP32', 'Buffer Cleared', 'ESP32 point buffer was cleared by CLEAN command', 'LOW'),
    (2000, 'ESP32', 'X Limit Reached', 'X axis limit switch is active', 'MEDIUM'),
    (2001, 'ESP32', 'Y Limit Reached', 'Y axis limit switch is active', 'MEDIUM'),
    (3000, 'ESP32', 'Emergency Stop', 'Emergency stop input is active', 'HIGH'),
    (3001, 'ESP32', 'Motion Interrupted', 'Automatic or target movement was interrupted by STOP or E-STOP', 'HIGH'),
    (3500, 'PLC', 'ESP Communication Lost', 'No valid communication with ESP32', 'HIGH')
ON CONFLICT (code)
DO UPDATE SET
    source = EXCLUDED.source,
    name = EXCLUDED.name,
    description = EXCLUDED.description,
    priority = EXCLUDED.priority;