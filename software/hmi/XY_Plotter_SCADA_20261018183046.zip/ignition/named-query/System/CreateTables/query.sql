CREATE TABLE IF NOT EXISTS drawing (
    drawing_id SERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    file_name VARCHAR NOT NULL,
    gcode_text TEXT NOT NULL,
    svg_preview TEXT NOT NULL,
    width_mm NUMERIC,
    height_mm NUMERIC,
    point_count INTEGER,
    contour_count INTEGER,
    active BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT NOW(),
    min_x NUMERIC,
    max_x NUMERIC,
    min_y NUMERIC,
    max_y NUMERIC,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS drawing_history (
    id BIGSERIAL PRIMARY KEY,
    drawing_id INTEGER NOT NULL,
    start_timestamp TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finish_timestamp TIMESTAMP WITHOUT TIME ZONE,
    result VARCHAR NOT NULL DEFAULT 'ACTIVE',
    points_completed INTEGER NOT NULL DEFAULT 0,
    error_code INTEGER,
    FOREIGN KEY (drawing_id) REFERENCES drawing(drawing_id),
    CHECK (result IN ('ACTIVE', 'COMPLETED', 'FAILED', 'STOPPED')),
    CHECK (points_completed >= 0)
);

CREATE TABLE IF NOT EXISTS error_catalog (
    code INTEGER PRIMARY KEY,
    source VARCHAR NOT NULL,
    name VARCHAR NOT NULL,
    description TEXT,
    priority VARCHAR NOT NULL
);

CREATE TABLE IF NOT EXISTS error_history (
    id BIGSERIAL PRIMARY KEY,
    code INTEGER NOT NULL,
    start_timestamp TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finish_timestamp TIMESTAMP WITHOUT TIME ZONE,
    state VARCHAR NOT NULL
);