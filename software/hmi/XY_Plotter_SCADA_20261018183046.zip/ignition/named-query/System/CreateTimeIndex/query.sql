-- Called from GW startUp script
-- Creates an index on comm_log.event_time for faster history queries
CREATE INDEX IF NOT EXISTS idx_comm_log_event_time
ON comm_log(event_time DESC);