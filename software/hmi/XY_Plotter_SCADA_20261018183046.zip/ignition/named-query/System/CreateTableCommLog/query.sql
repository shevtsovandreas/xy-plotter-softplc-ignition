-- Called from GW startUp script
-- Creates the communication event log table if it does not exist
CREATE TABLE IF NOT EXISTS comm_log (
    id BIGSERIAL PRIMARY KEY,
    event_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    signal_id INT NOT NULL,
    old_value SMALLINT NOT NULL,
    new_value SMALLINT NOT NULL,

    CONSTRAINT fk_comm_log_signal
        FOREIGN KEY (signal_id)
        REFERENCES comm_signal(id)
);