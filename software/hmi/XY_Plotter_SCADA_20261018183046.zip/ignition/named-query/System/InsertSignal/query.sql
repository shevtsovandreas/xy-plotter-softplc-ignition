-- Called from GW script -- startUp.comm.setupSignals()
-- Inserts or updates a communication signal definition
INSERT INTO comm_signal
(
    register_name,
    data_type,
    bit_number,
    signal_name,
    description,
    direction,
    operation_type
)
VALUES
(
    :register_name,
    :data_type,
    :bit_number,
    :signal_name,
    :description,
    :direction,
    :operation_type
)
ON CONFLICT (register_name, bit_number)
DO UPDATE SET
    data_type      = EXCLUDED.data_type,
    signal_name    = EXCLUDED.signal_name,
    description    = EXCLUDED.description,
    direction      = EXCLUDED.direction,
    operation_type = EXCLUDED.operation_type;