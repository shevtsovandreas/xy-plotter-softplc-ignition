-- Called from GW startUp script
-- Creates an index on comm_log.signal_id for faster signal lookups
CREATE INDEX IF NOT EXISTS idx_comm_log_signal_id
ON comm_log(signal_id);