-- Called from GW startUp script
-- Creates the communication signal definition table if it does not exist
CREATE TABLE IF NOT EXISTS comm_signal (
    id SERIAL PRIMARY KEY,
    register_name VARCHAR(20) NOT NULL,
    data_type VARCHAR(10) NOT NULL,
    bit_number INT NOT NULL,
    signal_name VARCHAR(100) NOT NULL,
    description VARCHAR(255),
    direction VARCHAR(20) NOT NULL,
    operation_type VARCHAR(10) NOT NULL,

    CONSTRAINT uq_comm_signal UNIQUE (register_name, bit_number)
);