INSERT INTO drawing_history (drawing_id)
VALUES (:drawing_id)
RETURNING id;