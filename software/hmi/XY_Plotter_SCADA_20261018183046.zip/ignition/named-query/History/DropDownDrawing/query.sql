SELECT
    drawing_id AS value,
    name AS label
FROM drawing
ORDER BY name;