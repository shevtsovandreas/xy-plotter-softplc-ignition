SELECT
    h.id,
    h.drawing_id,
    d.name AS drawing_name,
    h.start_timestamp,
    h.finish_timestamp,
    h.result,
    h.points_completed,
    d.point_count AS points_total,
    h.error_code
FROM drawing_history h
JOIN drawing d
    ON d.drawing_id = h.drawing_id
WHERE
    h.start_timestamp::date >= CAST(:DateFrom AS date)
    AND h.start_timestamp::date <= CAST(:DateTo AS date)
    AND (:DrwName = 0 OR h.drawing_id = :DrwName)
    AND (:Result = '' OR h.result = :Result)
ORDER BY h.start_timestamp DESC;