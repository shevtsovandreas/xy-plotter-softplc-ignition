SELECT contour_count, file_name, height_mm, width_mm, svg_preview
FROM drawing d
WHERE d.drawing_id = :drawing_id