UPDATE drawing_history
SET
    finish_timestamp = CURRENT_TIMESTAMP,
    points_completed = :points_completed,
    result = :result,
    error_code = :error_code
WHERE id = :execution_id;