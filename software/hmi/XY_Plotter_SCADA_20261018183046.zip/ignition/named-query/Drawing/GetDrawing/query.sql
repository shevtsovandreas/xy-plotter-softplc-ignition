-- Called from Shared/PopUp/PopUpPreview -> StartUp event
SELECT
    drawing_id,
    file_name,
    name,    
    gcode_text,
    svg_preview,
    point_count,
    contour_count,
    min_x,
    min_y,
    max_x,
    max_y,
    height_mm,
    width_mm,
    active
FROM drawing
WHERE drawing_id = :drawing_id 
ORDER BY drawing_id DESC