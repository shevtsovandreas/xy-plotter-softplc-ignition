WITH updated AS (
    UPDATE public.drawing
    SET name = :new_name
    WHERE drawing_id = :drawing_id
      AND NOT EXISTS (
          SELECT 1
          FROM public.drawing
          WHERE name = :new_name AND drawing_id != :drawing_id
      )
    RETURNING drawing_id
)

SELECT
    CASE
        WHEN EXISTS (SELECT 1 FROM updated)
        THEN 'UPDATED'
        ELSE 'EXISTS'
    END AS result;