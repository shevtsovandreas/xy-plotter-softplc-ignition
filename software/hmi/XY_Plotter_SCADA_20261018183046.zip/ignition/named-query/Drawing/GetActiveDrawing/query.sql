-- Called from GW script svgGeneration.gcodeMainView.loadActiveDrawing 
-- Get active drawing from database
SELECT
    drawing_id,
    name,
    gcode_text
FROM drawing
WHERE active = TRUE
LIMIT 1;