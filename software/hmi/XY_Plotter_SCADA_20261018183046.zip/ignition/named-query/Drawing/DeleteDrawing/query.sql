-- Called from Shared/Library/LibraryCard -> Delete Button
UPDATE drawing
SET is_deleted = TRUE
WHERE drawing_id = :drawing_id;