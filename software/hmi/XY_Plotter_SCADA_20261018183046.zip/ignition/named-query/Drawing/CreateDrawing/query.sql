WITH inserted AS (
    INSERT INTO public.drawing (
        name,
        file_name,
        gcode_text,
        svg_preview,
        width_mm,
        height_mm,
        min_x,
        max_x,
        min_y,
        max_y,
        point_count,
        contour_count
    )
    VALUES (
        :name,
        :file_name,
        :gcode_text,
        :svg_preview,
        :width_mm,
        :height_mm,
        :min_x,
        :max_x,
        :min_y,
        :max_y,
        :point_count,
        :contour_count
    )
    ON CONFLICT DO NOTHING
    RETURNING drawing_id
)
SELECT CASE
    WHEN EXISTS (SELECT 1 FROM inserted) THEN 'CREATED'
    ELSE 'EXISTS'
END AS result;