-- Called from GW script gcodeTransfer/gcodeSend
SELECT gcode_text
FROM drawing
WHERE drawing_id = :drawing_id 