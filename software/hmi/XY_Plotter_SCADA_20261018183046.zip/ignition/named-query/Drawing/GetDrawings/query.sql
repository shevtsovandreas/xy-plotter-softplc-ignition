-- Called from Pages/1_Library -> Flexrepeater -> Instances
SELECT
    drawing_id,
    name,
    svg_preview,
    width_mm,
    height_mm,
    point_count,
    contour_count,
    active
FROM drawing
WHERE is_deleted = FALSE
ORDER BY created_at DESC