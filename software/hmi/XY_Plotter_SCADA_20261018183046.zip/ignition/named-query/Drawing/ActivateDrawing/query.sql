-- Called from Shared/Library/LibraryCard -> Activate Button
-- Set the selected blueprint to true and all others to false
UPDATE drawing
SET active = CASE
    WHEN drawing_id = :drawing_id THEN TRUE
    ELSE FALSE
END;