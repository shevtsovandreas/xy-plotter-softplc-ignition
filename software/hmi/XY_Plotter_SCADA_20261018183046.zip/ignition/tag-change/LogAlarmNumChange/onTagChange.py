def onTagChange(initialChange, newValue, previousValue, event, executionCount):
	
	# Detects PLC error number changes
	tableLogs.addLog.logAlarmChange(previousValue, newValue)