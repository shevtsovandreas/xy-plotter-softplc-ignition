def onTagChange(initialChange, newValue, previousValue, event, executionCount):
	
	# Detects ESP32 status register 1 changes and logs changed bits
	tableLogs.addLog.logRegisterChange("ZSW1", previousValue, newValue, 8)
	