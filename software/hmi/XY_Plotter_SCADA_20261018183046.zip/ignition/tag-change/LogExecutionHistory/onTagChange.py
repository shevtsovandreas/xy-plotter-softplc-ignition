def onTagChange(initialChange, newValue, previousValue, event, executionCount):
	
	if not initialChange:
	
		oldState = previousValue.value
		newState = newValue.value
	
		# Drawing started
		if newState == 1 and oldState != 1:
	
			drawingId = system.tag.readBlocking(["[default]Memory_tags/DrawingId"])[0].value
	
			if drawingId is not None:
	
				result = system.db.runNamedQuery("History/StartExecution", {"drawing_id": drawingId})
				executionId = result.getValueAt(0, 0)
	
				system.tag.writeBlocking(["[default]Memory_tags/DrawingExecutionId"], [executionId])
	
		# Drawing finished or aborted
		elif newState in (2, 3):
	
			values = system.tag.readBlocking([
				"[default]Memory_tags/DrawingExecutionId",
				"[default]ESP32_Response/ResponseCurrPoint",
				"[default]ESP32_Response/ResponseErrorCode"
			])
	
			executionId = values[0].value
			pointsCompleted = values[1].value
			errorCode = values[2].value
	
			if executionId is not None and int(executionId) > 0:
	
				if errorCode is not None and int(errorCode) != 0:
					result = "FAILED"
	
				elif newState == 2:
					result = "STOPPED"
	
				else:
					result = "COMPLETED"
	
				if pointsCompleted is None:
					pointsCompleted = 0
	
				system.db.runNamedQuery("History/FinishExecution", {
					"execution_id": executionId,
					"points_completed": pointsCompleted,
					"result": result,
					"error_code": errorCode if errorCode is not None else None
				})
	
				system.tag.writeBlocking(["[default]Memory_tags/DrawingExecutionId"], [0])