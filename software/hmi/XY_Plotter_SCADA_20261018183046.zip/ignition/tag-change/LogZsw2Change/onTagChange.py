def onTagChange(initialChange, newValue, previousValue, event, executionCount):
	
    # Detects ESP32 status register 2 changes and logs changed bits
    tableLogs.addLog.logRegisterChange("ZSW2", previousValue, newValue, 8)