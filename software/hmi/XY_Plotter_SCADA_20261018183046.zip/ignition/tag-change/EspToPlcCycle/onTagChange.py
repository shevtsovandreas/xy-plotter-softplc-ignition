def onTagChange(initialChange, newValue, previousValue, event, executionCount):
	    
    if not initialChange:   
	    cycle = system.date.millisBetween(previousValue.timestamp, newValue.timestamp)	
    else:
    	cycle = 999999
    	
    system.tag.writeBlocking(["[default]Memory_tags/EspToPlcCycle"], [cycle])	