def onTagChange(initialChange, newValue, previousValue, event, executionCount):
	
	# Detects PLC command register changes and logs changed bits
	tableLogs.addLog.logRegisterChange("STW", previousValue, newValue, 16)
	