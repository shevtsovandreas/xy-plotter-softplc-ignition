def doGet(request, session):

    paths = [
        "[default]ESP32_Response/ResponseCoord_X",
        "[default]ESP32_Response/ResponseCoord_Y",
        "[default]ESP32_Response/ResponseZswByte1"
    ]

    values = system.tag.readBlocking(paths)

    if not all(v.quality.isGood() for v in values):
        return {
            "json": {
                "error": "Bad tag quality"
            }
        }

    data = {
        "x": float(values[0].value) / 100.0,
        "y": float(values[1].value) / 100.0,
        "penDown": bool(int(values[2].value) & (1 << 5))
    }

    return {"json": data}