def doTrace(request, session):
